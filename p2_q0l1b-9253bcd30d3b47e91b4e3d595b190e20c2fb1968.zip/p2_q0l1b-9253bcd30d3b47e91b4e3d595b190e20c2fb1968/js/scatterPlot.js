class ScatterPlot {

  constructor() {
    
  }
  
  initVis() {
    // Create SVG area, initialize scales and axes
  }

  updateVis() {
    // Prepare data and scales
  }

  renderVis() {
    // Bind data to visual elements, update axes
  }

}